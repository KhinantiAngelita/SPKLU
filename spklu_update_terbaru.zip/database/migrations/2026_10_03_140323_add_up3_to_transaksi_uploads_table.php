<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('transaksi_uploads', function (Blueprint $table) {
            $table->string('up3', 100)->default('UP3 Bogor')->after('diupload_oleh')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('transaksi_uploads', function (Blueprint $table) {
            $table->dropIndex(['up3']);
            $table->dropColumn('up3');
        });
    }
};
