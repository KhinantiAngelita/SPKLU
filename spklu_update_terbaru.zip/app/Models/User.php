<?php

namespace App\Models;

use App\Enums\UserStatus;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use Notifiable;

    public const UP3_MAP = [
        'BDG' => 'UP3 Bandung',
        'BGR' => 'UP3 Bogor',
        'BKS' => 'UP3 Bekasi',
        'CJR' => 'UP3 Cianjur',
        'CKG' => 'UP3 Cikarang',
        'CMI' => 'UP3 Cimahi',
        'CRB' => 'UP3 Cirebon',
        'DPK' => 'UP3 Depok',
        'GPI' => 'UP3 Gunung Putri',
        'GRT' => 'UP3 Garut',
        'IDM' => 'UP3 Indramayu',
        'KRW' => 'UP3 Karawang',
        'MJA' => 'UP3 Majalaya',
        'PWK' => 'UP3 Purwakarta',
        'SKI' => 'UP3 Sukabumi',
        'SMD' => 'UP3 Sumedang',
        'TSK' => 'UP3 Tasikmalaya',
        'UID' => 'UID Jawa Barat',
    ];

    public const DAFTAR_UP3 = [
        'UP3 Bandung',
        'UP3 Bekasi',
        'UP3 Bogor',
        'UP3 Cianjur',
        'UP3 Cikarang',
        'UP3 Cimahi',
        'UP3 Cirebon',
        'UP3 Depok',
        'UP3 Garut',
        'UP3 Gunung Putri',
        'UP3 Indramayu',
        'UP3 Karawang',
        'UP3 Majalaya',
        'UP3 Purwakarta',
        'UP3 Sukabumi',
        'UP3 Sumedang',
        'UP3 Tasikmalaya',
        'UID Jawa Barat',
    ];

    protected $fillable = [
        'name', 'email', 'password', 'role', 'up3', 'status',
        'google_id', 'avatar', 'invited_by',
        'invitation_token', 'invitation_expires_at',
        'force_password_change', 'created_directly_by',
        'requires_otp_first_login', 'first_login_verified_at',
        'otp_code', 'otp_expires_at', 'otp_attempts',
        'last_read_notification_at',
        'last_login_at',
    ];

    protected $hidden = ['password', 'otp_code', 'remember_token'];

    protected $casts = [
        'status' => UserStatus::class,
        'force_password_change' => 'boolean',
        'requires_otp_first_login' => 'boolean',
        'email_verified_at' => 'datetime',
        'invitation_expires_at' => 'datetime',
        'otp_expires_at' => 'datetime',
        'last_login_at' => 'datetime',
        'first_login_verified_at' => 'datetime',
        'last_read_notification_at' => 'datetime',
    ];

    // ---------- Relasi ----------

    public function invitedBy()
    {
        return $this->belongsTo(User::class, 'invited_by');
    }

    public function createdDirectlyBy()
    {
        return $this->belongsTo(User::class, 'created_directly_by');
    }

    public function riwayatAktivasi()
    {
        return $this->hasMany(RiwayatAktivasi::class, 'user_id');
    }

    public function riwayatAktivasiTerakhir()
    {
        return $this->hasOne(RiwayatAktivasi::class, 'user_id')->latestOfMany();
    }

    // ---------- Helper Undangan ----------

    public static function generateInvitationToken(): string
    {
        return Str::random(64);
    }

    public function invitationIsExpired(): bool
    {
        return $this->invitation_expires_at && $this->invitation_expires_at->isPast();
    }

    // ---------- Helper OTP ----------

    public function generateOtp(): string
    {
        $code = (string) random_int(100000, 999999);

        $this->update([
            'otp_code' => Hash::make($code),
            'otp_expires_at' => now()->addMinutes(10),
            'otp_attempts' => 0,
        ]);

        return $code; // dikirim via email, TIDAK disimpan plain di DB
    }

    public function verifyOtp(string $inputCode): bool
    {
        if (! $this->otp_code || ! $this->otp_expires_at || $this->otp_expires_at->isPast()) {
            return false;
        }

        if ($this->otp_attempts >= 5) {
            return false;
        }

        if (! Hash::check($inputCode, $this->otp_code)) {
            $this->increment('otp_attempts');

            return false;
        }

        return true;
    }

    public function clearOtp(): void
    {
        $this->update([
            'otp_code' => null,
            'otp_expires_at' => null,
            'otp_attempts' => 0,
        ]);
    }

    public function needsFirstLoginOtp(): bool
    {
        return $this->requires_otp_first_login && ! $this->first_login_verified_at;
    }

    public function activate(): void
    {
        $this->update([
            'status' => UserStatus::Active,
            'invitation_token' => null,
            'invitation_expires_at' => null,
            'email_verified_at' => now(),
        ]);
        $this->clearOtp();
    }

    public function isActive(): bool
    {
        return $this->status === UserStatus::Active;
    }

    public function isSuperAdmin(): bool
    {
        return $this->role === 'super_admin';
    }

    public function getUnitLabelAttribute(): string
    {
        return $this->up3 ?: 'UID Jawa Barat';
    }
}
