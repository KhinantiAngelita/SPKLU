<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'Sistem SPKLU' }}</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}?v=2">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('favicon.ico') }}?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}?v=2">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}?v=2">
    <link rel="icon" type="image/png" href="{{ asset('images/logo-revolution-circle.png') }}?v=2">
    <link rel="apple-touch-icon" href="{{ asset('apple-touch-icon.png') }}?v=2">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="https://unpkg.com/lucide@latest"></script>
    @stack('styles')
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --brand-dark: #023E8A;
            --brand-mid: #0081AB;
            --brand-light: #4FC3E0;
            --accent-yellow: #FFC629;
            --status-green: #2E9E5B;
            --status-amber: #E8A317;
            --status-red: #C0392B;
            --bg-page: #F4F6FB;
            --header-color: #1B2559;
            --text-primary: #0F172A;
            --text-secondary: #64748B;
        }

        * { box-sizing: border-box; }
        button, input, select, textarea { font-family: inherit; }
        body { margin: 0; font-family: 'Inter', ui-sans-serif, system-ui, sans-serif; background-color: var(--bg-page); color: var(--text-primary); -webkit-font-smoothing: antialiased; }
        a { text-decoration: none; color: inherit; }

        /* ===== Universal Header Color (#1B2559) ===== */
        h1, h2, h3,
        .app-page-title,
        .section-header-bar h2,
        .surface-card h2,
        .dsh-welcome-title,
        .section-title {
            color: #1B2559 !important;
        }

        .app-shell { display: flex; height: 100vh; overflow: hidden; }
        .app-main { flex: 1; display: flex; flex-direction: column; overflow: hidden; min-width: 0; }
        .app-content { flex: 1; overflow-y: auto; padding: 26px 28px; animation: contentFadeIn .35s ease; }

        @keyframes contentFadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== Universal Page Header Style ===== */
        .app-page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 1px solid #eef1f5;
            flex-wrap: wrap;
            gap: 14px;
        }
        .app-page-title {
            font-size: 22px;
            font-weight: 800;
            color: #1B2559 !important;
            letter-spacing: -0.015em;
            margin: 0;
            line-height: 1.25;
        }
        .app-page-subtitle {
            color: #64748B;
            font-size: 13.5px;
            margin: 4px 0 0;
            font-weight: 500;
            line-height: 1.4;
        }

        /* ===== Class global dipakai lintas halaman: header section putih bersih (seperti dashboard) ===== */
        .section-header-bar {
            background: #FFFFFF !important;
            padding: 18px 24px;
            border-bottom: 1px solid #F1F5F9;
            display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;
        }
        .section-header-bar-left { display: flex; align-items: center; gap: 12px; }
        .section-header-bar-icon {
            width: 34px; height: 34px; min-width: 34px; border-radius: 10px;
            background: linear-gradient(135deg, var(--brand-dark), var(--brand-mid));
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 3px 8px rgba(2,62,138,.25);
        }
        .section-header-bar-icon svg { width: 17px; height: 17px; color: #fff; stroke-width: 2; }
        .section-header-bar h2 { margin: 0; font-size: 16.5px; font-weight: 800; color: #1B2559 !important; }
        .section-header-bar p { margin: 3px 0 0; font-size: 12px; color: var(--text-secondary); }

        .surface-card {
            background: #fff; border-radius: 18px; border: 1px solid #eef1f5;
            box-shadow: 0 1px 2px rgba(15,23,42,.04), 0 6px 20px rgba(15,23,42,.05);
            overflow: hidden; margin-bottom: 22px;
        }

        /* ===== Filter bar — grouping rapi, gak "pecah" pas layar sempit ===== */
        .filter-shell {
            background: linear-gradient(135deg, rgba(2,62,138,.04), rgba(0,129,171,.06));
            border: 1px solid rgba(0,129,171,.14);
            border-radius: 16px;
            padding: 18px 22px;
            margin-bottom: 22px;
            display: flex;
            flex-direction: column;
            gap: 14px;
        }
        .filter-shell-row {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
        }
        .filter-shell-row:first-child { justify-content: space-between; }
        .filter-label-inline {
            display: flex; align-items: center; gap: 8px;
            font-size: 17px; font-weight: 800; color: var(--brand-dark); letter-spacing: -0.01em;
            flex-shrink: 0;
        }
        .filter-label-inline svg { width: 18px; height: 18px; stroke-width: 2.2; }
        .filter-divider { width: 1px; height: 22px; background: rgba(0,129,171,.18); flex-shrink: 0; }

        /* ===== Row icon kecil, dipakai di kolom pertama tabel manapun ===== */
        .row-icon-cell { display: flex; align-items: center; gap: 10px; }
        .row-icon-box {
            width: 30px; height: 30px; min-width: 30px; border-radius: 8px;
            background: rgba(0,129,171,.1); color: var(--brand-mid);
            display: flex; align-items: center; justify-content: center;
        }
        .row-icon-box svg { width: 14px; height: 14px; stroke-width: 2; }
        .row-icon-box.amber { background: rgba(232,163,23,.14); color: #92660f; }
        .row-icon-box.green { background: rgba(46,158,91,.12); color: var(--status-green); }

        /* ===== Modal animasi masuk, dipakai semua family modal (.trx-, .msp-, .up-) ===== */
        @keyframes modalPop {
            from { opacity: 0; transform: scale(.96) translateY(6px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
        [class*="-modal-overlay"] > [class*="-modal"] { animation: modalPop .18s cubic-bezier(.34,1.56,.64,1); }

        /* ===== Sidebar ===== */

        .sidebar {
            width: 276px; flex-shrink: 0; color: #fff; display: flex; flex-direction: column;
            background: linear-gradient(160deg, #023E8A 0%, #034d9e 35%, #0081AB 100%);
            position: relative;
            transition: width .25s cubic-bezier(.4,0,.2,1);
        }
        .sidebar::after {
            content: ''; position: absolute; inset: 0; pointer-events: none;
            background: radial-gradient(circle at 85% 0%, rgba(255,255,255,0.07), transparent 45%);
        }

        .sidebar-logo { display: flex; align-items: center; gap: 14px; padding: 26px 24px 22px; position: relative; z-index: 1; transition: padding .25s ease, justify-content .25s ease; }

        /* BARU: badge logo jadi lingkaran putih solid berisi logo rEVolution
           asli — sama konsepnya kayak badge di halaman login, cuma
           ukurannya disesuaikan lebih kecil supaya pas di sidebar. */
        .sidebar-logo-icon {
            width: 44px; height: 44px; border-radius: 50%;
            background: #fff;
            display: flex; align-items: center; justify-content: center; flex-shrink: 0;
            box-shadow: 0 3px 10px rgba(0,0,0,.18);
            padding: 3px;
            transition: width .25s ease, height .25s ease;
        }
        .sidebar-logo-icon img { width: 100%; height: 100%; object-fit: contain; border-radius: 50%; }
        .sidebar-logo-text { transition: opacity .15s ease; white-space: nowrap; overflow: hidden; }
        .sidebar-logo-text .title { font-weight: 800; font-size: 15px; letter-spacing: -0.01em; line-height: 1.2; margin: 0; }
        .sidebar-logo-text .subtitle { font-size: 11.5px; color: rgba(255,255,255,0.65); line-height: 1.2; margin: 2px 0 0; font-weight: 500; }

        .sidebar-nav { flex: 1; overflow-y: auto; overflow-x: hidden; padding: 10px 16px 20px; position: relative; z-index: 1; }
        .sidebar-nav::-webkit-scrollbar { width: 4px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 4px; }

        .sidebar-nav > * { opacity: 0; animation: menuSlideIn .4s ease forwards; }
        .sidebar-nav > *:nth-child(1) { animation-delay: .02s; }
        .sidebar-nav > *:nth-child(2) { animation-delay: .06s; }
        .sidebar-nav > *:nth-child(3) { animation-delay: .10s; }
        .sidebar-nav > *:nth-child(4) { animation-delay: .14s; }
        .sidebar-nav > *:nth-child(5) { animation-delay: .18s; }
        .sidebar-nav > *:nth-child(6) { animation-delay: .22s; }
        .sidebar-nav > *:nth-child(7) { animation-delay: .26s; }
        .sidebar-nav > *:nth-child(8) { animation-delay: .30s; }
        .sidebar-nav > *:nth-child(9) { animation-delay: .34s; }
        .sidebar-nav > *:nth-child(10) { animation-delay: .38s; }

        @keyframes menuSlideIn {
            from { opacity: 0; transform: translateX(-8px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .sidebar-link {
            display: flex; align-items: center; justify-content: flex-start; gap: 12px; padding: 10.5px 15px; border-radius: 11px;
            font-size: 13.8px; font-weight: 500; color: rgba(255,255,255,0.75);
            margin-bottom: 4px; cursor: pointer; border: none; background: none; width: 100%; text-align: left;
            transition: background-color .2s ease, color .2s ease, transform .15s ease, padding .2s ease, justify-content .2s ease;
            position: relative;
        }
        .sidebar-link:hover { color: #fff; background-color: rgba(255,255,255,0.09); transform: translateX(2px); }
        .sidebar-link.active {
            color: #fff; font-weight: 600;
            background: linear-gradient(90deg, rgba(255,198,41,0.2), rgba(255,255,255,0.06));
            border-left: 3px solid var(--accent-yellow); padding-left: 12px;
            box-shadow: inset 0 0 0 1px rgba(255,255,255,.06);
        }
        .sidebar-link-content {
            display: flex;
            align-items: center;
            gap: 12px;
            transition: gap .2s ease, justify-content .2s ease;
        }
        .sidebar-link i, .sidebar-link svg {
            width: 17px; height: 17px; flex-shrink: 0; transition: transform .2s ease, filter .2s ease;
        }
        .sidebar-link:hover i, .sidebar-link:hover svg { transform: scale(1.12); }
        .sidebar-link.active i, .sidebar-link.active svg { filter: drop-shadow(0 0 5px rgba(255,198,41,.55)); }

        .sidebar-group-toggle { display: flex; align-items: center; justify-content: space-between; }
        .sidebar-group-toggle .chevron { width: 14px; height: 14px; transition: transform 0.25s cubic-bezier(.4,0,.2,1), opacity .15s ease; opacity: 0.7; }
        .sidebar-group-toggle.open .chevron { transform: rotate(180deg); }

        .sidebar-submenu {
            margin: 0 0 0 32px; padding-left: 14px; border-left: 1px solid rgba(255,255,255,0.14);
            max-height: 0; opacity: 0; overflow: hidden;
            transition: max-height .3s cubic-bezier(.4,0,.2,1), opacity .25s ease, margin .3s ease;
        }
        .sidebar-submenu.open { max-height: 300px; opacity: 1; margin: 3px 0 8px 32px; }

        .sidebar-sublink {
            display: block; padding: 8px 12px; border-radius: 8px; font-size: 13.3px;
            color: rgba(255,255,255,0.62); margin-bottom: 2px; transition: background-color .15s ease, color .15s ease, transform .15s ease;
        }
        .sidebar-sublink:hover { color: #fff; background-color: rgba(255,255,255,0.07); transform: translateX(2px); }
        .sidebar-sublink.active {
            color: #fff; background-color: rgba(255,255,255,0.11); font-weight: 600;
            border-left: 3px solid var(--accent-yellow); margin-left: -15px; padding-left: 12px;
        }

        .sidebar-footer { padding: 14px 16px 18px; border-top: 1px solid rgba(255,255,255,0.12); position: relative; z-index: 1; }
        .sidebar-user { display: flex; align-items: center; gap: 11px; padding: 8px 10px; border-radius: 10px; transition: background-color .15s ease, padding .2s ease, justify-content .2s ease; cursor: pointer; text-decoration: none; color: inherit; }
        .sidebar-user:hover { background-color: rgba(255,255,255,.08); }
        .sidebar-avatar {
            width: 34px; height: 34px; border-radius: 50%;
            background: linear-gradient(135deg, #FFC629 0%, #F59E0B 50%, #EA580C 100%);
            color: #fff;
            display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800; flex-shrink: 0;
            border: 1.5px solid rgba(255,255,255,0.45);
            box-shadow: 0 2px 8px rgba(234, 88, 12, 0.35);
        }
        .sidebar-user-name { font-size: 13.5px; font-weight: 600; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: opacity .15s ease; }
        .sidebar-logout-form button {
            display: flex; align-items: center; gap: 12px; width: 100%; padding: 9px 10px; border-radius: 10px;
            font-size: 13.3px; color: rgba(255,255,255,0.62); background: none; border: none; cursor: pointer;
            transition: background-color .15s ease, color .15s ease, padding .2s ease, justify-content .2s ease; margin-top: 4px;
        }
        .sidebar-logout-form button:hover { color: #fff; background-color: rgba(192,57,43,0.28); }
        .sidebar-logout-form i, .sidebar-logout-form svg { width: 16px; height: 16px; flex-shrink: 0; }

        /* =====================================================================
           Sidebar minimize/collapse — dikontrol lewat class "sidebar-collapsed"
           di <body>, di-toggle dari tombol di topbar dan disimpan ke
           localStorage supaya statenya nempel walau pindah halaman (server-
           rendered, bukan SPA, jadi tiap load halaman baru perlu dibaca ulang
           dari localStorage — lihat script kecil tepat setelah <body> yang
           nge-apply class ini SEBELUM sidebar sempat digambar, biar gak ada
           kedipan sidebar full lebar sesaat sebelum ke-collapse).
           ===================================================================== */
        body.sidebar-collapsed .sidebar { width: 76px; }

        body.sidebar-collapsed .sidebar-logo { justify-content: center; padding: 26px 0 22px; }
        body.sidebar-collapsed .sidebar-logo-text { display: none; }

        body.sidebar-collapsed .sidebar-link,
        body.sidebar-collapsed .sidebar-group-toggle {
            justify-content: center; padding: 10px 0;
        }
        body.sidebar-collapsed .sidebar-link.active { padding-left: 0; border-left: none; }
        body.sidebar-collapsed .sidebar-link-content { justify-content: center; gap: 0; }
        /* Trik: font-size:0 bikin teks label (text node biasa, nempel
           langsung setelah ikon di markup) visually hilang tanpa perlu
           bungkus ulang tiap label ke <span> terpisah di blade. Ikon svg/i
           gak kena efek karena ukurannya di-set eksplisit px, bukan em. */
        body.sidebar-collapsed .sidebar-link,
        body.sidebar-collapsed .sidebar-link-content { font-size: 0; }
        body.sidebar-collapsed .chevron,
        body.sidebar-collapsed .sidebar-submenu { display: none !important; }

        body.sidebar-collapsed .sidebar-user { justify-content: center; padding: 8px 0; }
        body.sidebar-collapsed .sidebar-user-name { display: none; }
        body.sidebar-collapsed .sidebar-logout-form button { justify-content: center; padding: 9px 0; font-size: 0; }

        /* =====================================================================
           Sidebar Light Mode — dikontrol lewat class "sidebar-light" di <body>,
           di-toggle lewat tombol di topbar dan disimpan di localStorage.
           ===================================================================== */
        body.sidebar-light .sidebar {
            background: #FFFFFF !important;
            color: #1E293B !important;
            border-right: 1px solid #E2E8F0 !important;
            box-shadow: 2px 0 16px rgba(15, 23, 42, 0.04) !important;
        }
        body.sidebar-light .sidebar::after {
            display: none !important;
        }
        body.sidebar-light .sidebar-logo-icon {
            background: #F8FAFC !important;
            border: 1px solid #E2E8F0 !important;
            box-shadow: 0 2px 6px rgba(15, 23, 42, 0.06) !important;
        }
        body.sidebar-light .sidebar-logo-text .title {
            color: #1B2559 !important;
        }
        body.sidebar-light .sidebar-logo-text .subtitle {
            color: #64748B !important;
        }
        body.sidebar-light .sidebar-link {
            color: #475569 !important;
        }
        body.sidebar-light .sidebar-link:hover {
            color: #023E8A !important;
            background-color: rgba(2, 62, 138, 0.06) !important;
        }
        body.sidebar-light .sidebar-link.active {
            color: #023E8A !important;
            font-weight: 700 !important;
            background: rgba(2, 62, 138, 0.08) !important;
            border-left: 3px solid #023E8A !important;
            box-shadow: none !important;
        }
        body.sidebar-light.sidebar-collapsed .sidebar-link.active {
            border-left: none !important;
        }
        body.sidebar-light .sidebar-link.active i,
        body.sidebar-light .sidebar-link.active svg {
            color: #023E8A !important;
            filter: drop-shadow(0 0 4px rgba(2, 62, 138, 0.25)) !important;
        }
        body.sidebar-light .sidebar-group-toggle .chevron {
            color: #64748B !important;
            opacity: 0.8 !important;
        }
        body.sidebar-light .sidebar-group-toggle:hover .chevron,
        body.sidebar-light .sidebar-group-toggle.open .chevron {
            color: #023E8A !important;
        }
        body.sidebar-light .sidebar-submenu {
            border-left: 1px solid #E2E8F0 !important;
        }
        body.sidebar-light .sidebar-sublink {
            color: #64748B !important;
        }
        body.sidebar-light .sidebar-sublink:hover {
            color: #023E8A !important;
            background-color: rgba(2, 62, 138, 0.06) !important;
        }
        body.sidebar-light .sidebar-sublink.active {
            color: #023E8A !important;
            background-color: rgba(2, 62, 138, 0.09) !important;
            font-weight: 700 !important;
            border-left: 3px solid #023E8A !important;
        }
        body.sidebar-light .sidebar-footer {
            border-top: 1px solid #F1F5F9 !important;
        }
        body.sidebar-light .sidebar-user {
            color: #1E293B !important;
        }
        body.sidebar-light .sidebar-user:hover {
            background-color: #F8FAFC !important;
        }
        body.sidebar-light .sidebar-user-name {
            color: #1B2559 !important;
        }
        body.sidebar-light .sidebar-avatar {
            border: 1.5px solid #E2E8F0 !important;
            box-shadow: 0 2px 8px rgba(245, 158, 11, 0.25) !important;
        }
        body.sidebar-light .sidebar-logout-form button {
            color: #64748B !important;
        }
        body.sidebar-light .sidebar-logout-form button:hover {
            color: #C0392B !important;
            background-color: rgba(192, 57, 43, 0.08) !important;
        }
        body.sidebar-light .sidebar-nav::-webkit-scrollbar-thumb {
            background: #CBD5E1 !important;
        }

        /* =====================================================================
           Topbar — dua grup: search rata kiri, notif+user rata kanan.
           ===================================================================== */

        .topbar {
            background: #fff; padding: 14px 28px; display: flex; align-items: center; justify-content: space-between;
            border-bottom: 1px solid #eef1f5;
            box-shadow: 0 1px 0 rgba(15,23,42,.02);
            position: relative; z-index: 20;
        }
        .topbar::after {
            content: ''; position: absolute; left: 0; right: 0; bottom: -1px; height: 3px;
            background: linear-gradient(90deg, var(--brand-dark), var(--brand-mid), transparent);
            opacity: .55;
        }

        .topbar-left { display: flex; align-items: center; gap: 12px; min-width: 0; }

        /* BARU: tombol minimize/expand sidebar, dipasang paling kiri topbar. */
        .sidebar-toggle-btn {
            width: 38px; height: 38px; min-width: 38px; border-radius: 11px; border: none; background: var(--bg-page);
            display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all .2s ease;
            color: var(--text-secondary);
        }
        .sidebar-toggle-btn:hover { background-color: #eef2f6; color: var(--brand-mid); }
        .sidebar-toggle-btn svg, .sidebar-toggle-btn i { width: 18px; height: 18px; }

        .topbar-actions { display: flex; align-items: center; gap: 8px; }

        .topbar-search {
            position: relative;
            display: flex;
            align-items: center;
        }
        /* FIX: dinaikkan specificity-nya (.topbar .topbar-search input) supaya
           gak kalah tie-break lawan rule global (mis. input[type=text]) di CSS
           modul halaman manapun yang di-load belakangan (probabilitas.css, dst) */
        .topbar .topbar-search input {
            padding: 11px 54px 11px 42px;
            font-size: 13.6px;
            border-radius: 999px;
            border: 1.5px solid #e7ebf0;
            background-color: var(--bg-page);
            width: 300px;
            transition: width .22s ease, border-color .2s ease, box-shadow .2s ease, background-color .2s ease;
        }
        .topbar-search input::placeholder { color: #9aa6b5; }
        .topbar-search input:focus {
            outline: none;
            border-color: var(--brand-light);
            box-shadow: 0 0 0 4px rgba(0,129,171,0.12);
            background: #fff;
            width: 360px;
        }
        .topbar-search:focus-within .topbar-search-kbd { opacity: 0; }
        /* FIX: cover direct child "i" (sebelum diganti) DAN "svg" (setelah lucide.createIcons() jalan) agar tidak menimpa svg di dalam dropdown */
        .topbar-search > i, .topbar-search > svg {
            position: absolute; left: 16px; top: 50%; transform: translateY(-50%);
            width: 16px; height: 16px; color: var(--text-secondary); pointer-events: none;
            transition: color .2s ease;
        }
        .topbar-search:focus-within > i,
        .topbar-search:focus-within > svg { color: var(--brand-mid); }
        .topbar-search-kbd {
            position: absolute; right: 14px; top: 50%; transform: translateY(-50%);
            font-size: 10.5px; font-weight: 700; color: var(--text-secondary);
            background: #fff; border: 1px solid #e2e8f0; border-radius: 6px;
            padding: 2px 7px; pointer-events: none; letter-spacing: .02em;
            transition: opacity .15s ease;
        }

        .topbar-divider { width: 1px; height: 26px; background: #eef1f5; margin: 0 6px; flex-shrink: 0; }

        .topbar-icon-btn {
            position: relative; width: 40px; height: 40px; border-radius: 12px; border: none; background: var(--bg-page);
            display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all .2s ease;
        }
        .topbar-icon-btn:hover { background-color: #eef2f6; transform: translateY(-1px); box-shadow: 0 3px 8px rgba(15,23,42,.06); }
        .topbar-icon-btn.is-open { background-color: #e0f0f5; box-shadow: inset 0 0 0 1.5px rgba(0,129,171,.35); }
        .topbar-icon-btn i, .topbar-icon-btn svg { width: 18px; height: 18px; color: var(--text-secondary); }
        .topbar-icon-btn.is-open i, .topbar-icon-btn.is-open svg { color: var(--brand-mid); }
        .topbar-notif-dot {
            position: absolute; top: 6px; right: 6px; min-width: 16px; height: 16px; padding: 0 3px; border-radius: 999px;
            background-color: var(--status-red); border: 2px solid #fff; color: #fff; font-size: 9.5px; font-weight: 800;
            display: flex; align-items: center; justify-content: center; line-height: 1;
        }

        /* ===== Dropdown generic (notifikasi & profil) ===== */
        .topbar-dropdown-wrap { position: relative; }
        .topbar-dropdown-panel {
            position: absolute; top: calc(100% + 12px); right: 0; width: 320px;
            background: #fff; border-radius: 16px; border: 1px solid #eef1f5;
            box-shadow: 0 12px 32px rgba(15,23,42,.14), 0 2px 6px rgba(15,23,42,.06);
            opacity: 0; visibility: hidden; transform: translateY(-6px) scale(.98);
            transition: opacity .16s ease, transform .16s ease, visibility .16s;
            z-index: 30; overflow: hidden;
        }
        .topbar-dropdown-panel.show { opacity: 1; visibility: visible; transform: translateY(0) scale(1); }
        .topbar-dropdown-panel::before {
            content: ''; position: absolute; top: -6px; right: 16px; width: 12px; height: 12px;
            background: #fff; border-left: 1px solid #eef1f5; border-top: 1px solid #eef1f5; transform: rotate(45deg);
        }

        .topbar-dropdown-header { padding: 16px 18px 12px; border-bottom: 1px solid #f5f7fa; }
        .topbar-dropdown-header h4 { margin: 0; font-size: 14px; font-weight: 800; color: var(--text-primary); }
        .topbar-dropdown-header p { margin: 2px 0 0; font-size: 11.5px; color: var(--text-secondary); }

        .topbar-notif-list { max-height: 320px; overflow-y: auto; }
        .topbar-notif-item {
            display: flex; gap: 12px; padding: 13px 18px; border-bottom: 1px solid #f5f7fa; cursor: pointer;
            transition: background-color .15s ease;
        }
        .topbar-notif-item:last-child { border-bottom: none; }
        .topbar-notif-item:hover { background: rgba(0,129,171,.05); }
        .topbar-notif-item.is-unread { background: rgba(0,129,171,.04); border-left: 3px solid var(--brand-mid); }
        .topbar-notif-item.is-unread .topbar-notif-text p { font-weight: 600; }
        .topbar-notif-icon {
            width: 34px; height: 34px; min-width: 34px; border-radius: 10px; background: rgba(0,129,171,.1); color: var(--brand-mid);
            display: flex; align-items: center; justify-content: center;
        }
        .topbar-notif-icon i, .topbar-notif-icon svg { width: 16px; height: 16px; }
        .topbar-notif-text p { margin: 0; font-size: 12.8px; color: var(--text-primary); line-height: 1.4; }
        .topbar-notif-text span { font-size: 11px; color: var(--text-secondary); }

        .topbar-dropdown-empty { padding: 34px 20px; text-align: center; color: var(--text-secondary); }
        .topbar-dropdown-empty i, .topbar-dropdown-empty svg { width: 30px; height: 30px; color: #cbd5e1; margin-bottom: 8px; }
        .topbar-dropdown-empty p { margin: 0; font-size: 13px; }

        .topbar-profile-summary { display: flex; align-items: center; gap: 12px; padding: 18px; }
        .topbar-profile-avatar {
            width: 44px; height: 44px; border-radius: 12px; background: linear-gradient(135deg, #FFC629 0%, #F59E0B 50%, #EA580C 100%);
            color: #fff; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 800; flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(234, 88, 12, .32);
        }
        .topbar-profile-summary h4 { margin: 0; font-size: 14.5px; font-weight: 800; color: var(--text-primary); }
        .topbar-profile-summary p { margin: 2px 0 0; font-size: 12px; color: var(--text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 190px; }

        .topbar-role-badge {
            display: inline-flex; align-items: center; gap: 5px; padding: 4px 10px; border-radius: 999px;
            font-size: 10.5px; font-weight: 700; margin-top: 6px;
        }
        .topbar-role-badge svg { width: 11px; height: 11px; stroke-width: 2.4; }
        .role-badge-super_admin { background: rgba(2,62,138,.12); color: var(--brand-dark); }
        .role-badge-pemasaran { background: rgba(0,129,171,.12); color: var(--brand-mid); }
        .role-badge-pengelola { background: rgba(46,158,91,.12); color: var(--status-green); }
        .role-badge-manajemen { background: #eef2f7; color: var(--text-secondary); }

        .topbar-dropdown-menu { padding: 8px; border-top: 1px solid #f5f7fa; }
        .topbar-dropdown-menu-item {
            display: flex; align-items: center; gap: 11px; width: 100%; padding: 10px 12px; border-radius: 10px;
            font-size: 13.3px; font-weight: 600; color: var(--text-primary); background: none; border: none; cursor: pointer;
            transition: background-color .15s ease;
        }
        .topbar-dropdown-menu-item:hover { background: var(--bg-page); }
        .topbar-dropdown-menu-item.danger { color: var(--status-red); }
        .topbar-dropdown-menu-item.danger:hover { background: rgba(192,57,43,.08); }
        .topbar-dropdown-menu-item i, .topbar-dropdown-menu-item svg { width: 16px; height: 16px; flex-shrink: 0; }

        .topbar-user {
            display: flex; align-items: center; gap: 10px; padding: 6px 12px 6px 6px;
            border-radius: 14px; cursor: pointer; transition: background-color .2s ease; border: none; background: none;
        }
        .topbar-user:hover, .topbar-user.is-open { background-color: var(--bg-page); }
        .topbar-avatar {
            width: 38px; height: 38px; border-radius: 11px; background: linear-gradient(135deg, #FFC629 0%, #F59E0B 50%, #EA580C 100%);
            color: #fff; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800; flex-shrink: 0;
            box-shadow: 0 3px 10px rgba(234, 88, 12, .32); position: relative;
        }
        .topbar-avatar::after {
            content: ''; position: absolute; bottom: -1px; right: -1px; width: 10px; height: 10px; border-radius: 50%;
            background: var(--status-green); border: 2px solid #fff;
        }
        .topbar-user-name { font-size: 13.8px; font-weight: 700; margin: 0; color: var(--text-primary); line-height: 1.3; }
        .topbar-user-role { font-size: 11.5px; margin: 0; color: var(--text-secondary); font-weight: 500; line-height: 1.3; }
        .topbar-user-chevron { width: 15px; height: 15px; color: var(--text-secondary); transition: transform .2s ease; flex-shrink: 0; }
        .topbar-user.is-open .topbar-user-chevron { transform: rotate(180deg); }

        @media (max-width: 768px) {
            .topbar-search { display: none; }
            .topbar-user-name, .topbar-user-role, .topbar-user-chevron { display: none; }
            .topbar-dropdown-panel { width: 280px; }
        }
    </style>
    @stack('styles')
    
</head>
<body>

    {{-- Dibaca & di-apply SEBELUM sidebar sempat digambar, supaya gak ada
         kedipan sidebar full-lebar atau kedipan mode sebelum ke-apply balik. --}}
    <script>
        if (localStorage.getItem('sidebarCollapsed') === '1') {
            document.body.classList.add('sidebar-collapsed');
        }
        if (localStorage.getItem('sidebarTheme') === 'light') {
            document.body.classList.add('sidebar-light');
        }
    </script>

    <div class="app-shell">

        @include('layouts.partials.sidebar')

        <div class="app-main">

            @include('layouts.partials.topbar')

            <main class="app-content">
                @yield('content')
            </main>

        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            lucide.createIcons();

            // ===== Submenu sidebar =====
            document.querySelectorAll('[data-toggle-submenu]').forEach(btn => {
                btn.addEventListener('click', () => {
                    const submenu = document.getElementById(btn.dataset.toggleSubmenu);
                    const isOpening = !submenu.classList.contains('open');

                    submenu.classList.toggle('open');
                    btn.classList.toggle('open');

                    if (isOpening) {
                        submenu.style.maxHeight = submenu.scrollHeight + 'px';
                    } else {
                        submenu.style.maxHeight = '0px';
                    }
                });
            });

            document.querySelectorAll('.sidebar-submenu.open').forEach(submenu => {
                submenu.style.maxHeight = submenu.scrollHeight + 'px';
            });

            // ===== Minimize/expand sidebar — state disimpan ke localStorage
            // supaya nempel walau pindah halaman (server-rendered, bukan SPA) =====
            const sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
            if (sidebarToggleBtn) {
                sidebarToggleBtn.addEventListener('click', () => {
                    const collapsed = document.body.classList.toggle('sidebar-collapsed');
                    localStorage.setItem('sidebarCollapsed', collapsed ? '1' : '0');
                });
            }

            // ===== Toggle Mode Sidebar (Terang / Gelap) =====
            const sidebarThemeBtn = document.getElementById('sidebar-theme-toggle-btn');
            const sunIconSpan = document.getElementById('sidebar-theme-icon-sun');
            const moonIconSpan = document.getElementById('sidebar-theme-icon-moon');

            function syncSidebarThemeUI(isLight) {
                if (sunIconSpan && moonIconSpan) {
                    if (isLight) {
                        sunIconSpan.style.display = 'none';
                        moonIconSpan.style.display = 'inline-flex';
                        if (sidebarThemeBtn) sidebarThemeBtn.title = 'Ganti ke Mode Gelap Sidebar';
                    } else {
                        sunIconSpan.style.display = 'inline-flex';
                        moonIconSpan.style.display = 'none';
                        if (sidebarThemeBtn) sidebarThemeBtn.title = 'Ganti ke Mode Terang Sidebar';
                    }
                }
            }

            if (sidebarThemeBtn) {
                syncSidebarThemeUI(document.body.classList.contains('sidebar-light'));
                sidebarThemeBtn.addEventListener('click', () => {
                    const isLight = document.body.classList.toggle('sidebar-light');
                    localStorage.setItem('sidebarTheme', isLight ? 'light' : 'dark');
                    syncSidebarThemeUI(isLight);
                });
            }

            // ===== Modal generic open/close =====
            document.querySelectorAll('[data-open-modal]').forEach(btn => {
                btn.addEventListener('click', () => {
                    document.getElementById(btn.dataset.openModal).style.display = 'flex';
                });
            });
            document.querySelectorAll('[data-close-modal]').forEach(btn => {
                btn.addEventListener('click', () => {
                    btn.closest('.modal-overlay, .msp-modal-overlay, .trx-modal-overlay, .up-modal-overlay').style.display = 'none';
                });
            });

            // ===== Konfirmasi SweetAlert, dipakai lintas halaman via atribut data-confirm =====
            document.querySelectorAll('form[data-confirm]').forEach(form => {
                form.addEventListener('submit', function (e) {
                    e.preventDefault();
                    const isDanger = form.dataset.confirmType === 'danger';

                    Swal.fire({
                        title: form.dataset.confirmTitle || 'Yakin?',
                        text: form.dataset.confirm,
                        icon: isDanger ? 'warning' : 'question',
                        showCancelButton: true,
                        confirmButtonColor: isDanger ? '#C0392B' : '#0081AB',
                        cancelButtonColor: '#94a3b8',
                        confirmButtonText: isDanger ? 'Ya, Hapus' : 'Ya, Lanjutkan',
                        cancelButtonText: 'Batal',
                        reverseButtons: true,
                        buttonsStyling: true,
                    }).then((result) => {
                        if (result.isConfirmed) form.submit();
                    });
                });
            });

            // ===== Toast notifikasi terpusat, SATU sumber, gak dobel lagi =====
            @if (session('success'))
                Swal.fire({
                    toast: true, position: 'top-end', icon: 'success',
                    title: @json(session('success')),
                    showConfirmButton: false, timer: 4500, timerProgressBar: true,
                });
            @endif

            @if (session('error'))
                Swal.fire({
                    toast: true, position: 'top-end', icon: 'error',
                    title: @json(session('error')),
                    showConfirmButton: false, timer: 5500, timerProgressBar: true,
                });
            @endif

            // ===== Dropdown topbar (notifikasi & profil) — generic, dipakai berapa pun jumlahnya =====
            const dropdownTriggers = document.querySelectorAll('[data-dropdown-trigger]');

            function closeAllDropdowns(except = null) {
                document.querySelectorAll('.topbar-dropdown-panel.show').forEach(panel => {
                    if (panel !== except) panel.classList.remove('show');
                });
                document.querySelectorAll('.is-open').forEach(el => {
                    if (el !== except) el.classList.remove('is-open');
                });
            }

            dropdownTriggers.forEach(trigger => {
                const panel = document.getElementById(trigger.dataset.dropdownTrigger);
                trigger.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const willOpen = !panel.classList.contains('show');
                    closeAllDropdowns(willOpen ? panel : null);
                    panel.classList.toggle('show', willOpen);
                    trigger.classList.toggle('is-open', willOpen);

                    if (willOpen && trigger.dataset.dropdownTrigger === 'panel-notifikasi') {
                        const dot = trigger.querySelector('.topbar-notif-dot');
                        if (dot) {
                            fetch('{{ route("notifikasi.baca-semua") }}', {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                    'Accept': 'application/json'
                                }
                            }).then(() => {
                                dot.remove();
                            }).catch(() => {});
                        }
                    }
                });
            });

            document.addEventListener('click', () => closeAllDropdowns());
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAllDropdowns(); });
        });
    </script>

    @stack('scripts')
</body>
</html>