@extends('layouts.app')

@section('breadcrumb', 'FS Skema')
@section('page-title', 'Tambah FS Skema')

@push('styles')
<style>
.fsf-wrap{display:grid;grid-template-columns:1.15fr 1fr;gap:20px;align-items:start}
@media (max-width:1100px){.fsf-wrap{grid-template-columns:1fr}}
.fsf-header{margin-bottom:24px}
.fsf-header h1{font-size:24px;font-weight:700;color:#1B2559;margin:0}
.fsf-header p{color:#64748B;margin:4px 0 0;font-size:14px}
.fsf-card{background:#fff;border-radius:14px;box-shadow:0 1px 3px rgba(15,23,42,.08);padding:28px}
.fsf-alert-error{background:#FEF2F2;border:1px solid #FECACA;color:#B91C1C;padding:12px 16px;border-radius:10px;margin-bottom:20px;font-size:14px}
.fsf-alert-error ul{margin:4px 0 0;padding-left:18px}
.fsf-tabs{display:flex;gap:8px;background:#F1F5F9;padding:4px;border-radius:10px;width:fit-content;margin-bottom:24px}
.fsf-tab{position:relative}
.fsf-tab input{position:absolute;opacity:0;cursor:pointer}
.fsf-tab span{display:block;padding:8px 22px;border-radius:8px;font-size:14px;font-weight:600;color:#64748B;cursor:pointer}
.fsf-tab input:checked + span{background:#fff;color:#0081AB;box-shadow:0 1px 2px rgba(15,23,42,.08)}
.fsf-section-title{font-size:15px;font-weight:700;margin:28px 0 14px;padding-top:20px;border-top:1px solid #F1F5F9;letter-spacing:.03em;text-transform:uppercase;color:#0081AB}
.fsf-row{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px}
.fsf-field label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:6px}
.fsf-field input,.fsf-field select,.fsf-field textarea{width:100%;padding:10px 12px;border:1px solid #E2E8F0;border-radius:8px;font-size:14px;color:#0F172A}
.fsf-field input:focus,.fsf-field select:focus{outline:none;border-color:#0081AB;box-shadow:0 0 0 3px rgba(0,129,171,.12)}
.fsf-field input[readonly]{background:#F1F5F9;color:#64748B;cursor:not-allowed}
.fsf-hint{font-size:12px;color:#94A3B8;margin-top:4px}
.fsf-label-group{font-size:13px;font-weight:600;color:#334155;margin-bottom:10px;display:block}
.fsf-chip-group{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:18px}
.fsf-chip{position:relative}
.fsf-chip input{position:absolute;opacity:0;cursor:pointer}
.fsf-chip span{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border:1px solid #E2E8F0;border-radius:999px;font-size:13px;font-weight:500;color:#475569;cursor:pointer}
.fsf-chip input:checked + span{background:rgba(0,129,171,.12);border-color:#0081AB;color:#023E8A}
.fsf-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:28px;padding-top:20px;border-top:1px solid #F1F5F9}
.fsf-btn-outline{padding:10px 20px;border-radius:8px;border:1px solid #E2E8F0;color:#475569;font-weight:600;font-size:14px;text-decoration:none}
.fsf-btn-primary{padding:10px 22px;border-radius:8px;border:none;background:#0081AB;color:#fff;font-weight:600;font-size:14px;cursor:pointer}
.fsf-skema3-only{display:none}

/* Combobox pencarian lokasi (sumber: Probabilitas) */
.fsf-combobox { position:relative; }
.fsf-combobox-trigger {
    display:flex; align-items:center; justify-content:space-between; gap:8px;
    width:100%; padding:10px 12px; border-radius:8px; border:1px solid #E2E8F0;
    background:#fff; font-size:14px; font-family:inherit; color:#94A3B8; cursor:pointer; text-align:left;
    transition:border-color .15s ease, box-shadow .15s ease;
}
.fsf-combobox-trigger:hover { border-color:#cbd5e1; }
.fsf-combobox.open .fsf-combobox-trigger,
.fsf-combobox-trigger:focus-visible { outline:none; border-color:#0081AB; box-shadow:0 0 0 3px rgba(0,129,171,.12); }
.fsf-combobox-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.fsf-combobox-label.has-value { color:#0F172A; font-weight:600; }
.fsf-combobox-chevron { width:13px; height:13px; color:#94A3B8; flex-shrink:0; transition:transform .15s ease; }
.fsf-combobox.open .fsf-combobox-chevron { transform:rotate(180deg); }

.fsf-combobox-panel {
    display:none;
    position:absolute; top:calc(100% + 4px); left:0; right:0; z-index:20;
    background:#fff; border:1px solid #E2E8F0; border-radius:10px;
    box-shadow:0 8px 24px rgba(15,23,42,.14);
    overflow:hidden;
}
.fsf-combobox-panel.open { display:block; }
.fsf-combobox-search {
    width:100%; box-sizing:border-box; padding:10px 12px; border:none; border-bottom:1px solid #F1F5F9;
    font-size:13.5px; font-family:inherit;
}
.fsf-combobox-search:focus { outline:none; background:#fbfcfd; }
.fsf-combobox-options { max-height:230px; overflow-y:auto; }
.fsf-combobox-option { padding:10px 12px; font-size:13.5px; color:#0F172A; cursor:pointer; }
.fsf-combobox-option:hover { background:rgba(0,129,171,.08); }
.fsf-combobox-option.selected { background:rgba(0,129,171,.12); color:#023E8A; font-weight:600; }
.fsf-combobox-empty { display:none; padding:16px 12px; font-size:13px; color:#94A3B8; text-align:center; }

.fsf-mini-card{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden;margin-top:8px}
.fsf-mini-card-header{background:#FFFFFF;padding:14px 20px;font-size:15px;font-weight:700;color:#1B2559;display:flex;align-items:center;gap:10px;border-bottom:1px solid #E2E8F0}
.fsf-mini-card-header svg{width:17px;height:17px;flex-shrink:0;stroke-width:2;color:#0081AB}
.fsf-mini-card-body{padding:18px 20px}

.fsp-card{background:#fff;border-radius:14px;box-shadow:0 1px 3px rgba(15,23,42,.08);overflow:hidden;margin-bottom:20px}
.fsp-card-header{background:#FFFFFF;padding:14px 20px;font-size:15px;font-weight:700;color:#1B2559;display:flex;align-items:center;gap:10px;border-bottom:1px solid #F1F5F9}
.fsp-card-header svg{width:17px;height:17px;flex-shrink:0;stroke-width:2;color:#0081AB}
.fsp-card-header .fsp-loading{color:#0081AB;font-size:12px;margin-left:auto}
.fsp-card-body{padding:18px 20px}
.fsp-table{width:100%;border-collapse:collapse;font-size:13px}
.fsp-table th{text-align:left;color:#94A3B8;font-weight:600;padding:8px 4px;border-bottom:1px solid #F1F5F9;white-space:nowrap}
.fsp-table td{padding:9px 4px;border-bottom:1px solid #F1F5F9;color:#334155;white-space:nowrap}
.fsp-jarak-bagus{color:#15803D;font-weight:600}
.fsp-jarak-risiko{color:#B91C1C;font-weight:600}
.fsp-jarak-belum{color:#94A3B8;font-style:italic}
.fsp-empty{color:#94A3B8;font-size:13px;padding:6px 0}
.fsp-poin-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9;font-size:13.5px}
.fsp-poin-row:last-child{border-bottom:none;font-weight:700;color:#0F172A}
.fsp-status-box{margin-top:14px;padding:10px 14px;border-radius:10px;font-size:13px;font-weight:600}
.fsp-status-hijau{background:#DCFCE7;color:#15803D}
.fsp-status-kuning{background:#FEF3C7;color:#B45309}
.fsp-status-merah{background:#FEE2E2;color:#B91C1C}
.fsp-status-netral{background:#F1F5F9;color:#64748B}
.fsp-narasi{font-size:13.5px;color:#475569;line-height:1.6;margin:0}
.fsp-narasi-placeholder{color:#94A3B8;font-style:italic;font-size:13px}
.fsp-loading{font-size:12px;color:#0081AB;font-weight:600}
.fsp-estimasi-roi{margin-top:14px;padding:12px 14px;background:#F8FAFC;border-radius:8px;font-size:13px;color:#334155;line-height:1.7}
.fsp-estimasi-roi strong{color:#0F172A}
.fsp-chart-error{color:#B91C1C;font-size:12.5px;line-height:1.6}
</style>
@endpush

@section('content')
<div class="fsf-header">
    <h1>Tambah FS Skema</h1>
    <p>Hitung kelayakan lokasi SPKLU baru</p>
</div>

<div class="fsf-wrap">
    {{-- KOLOM KIRI: FORM --}}
    <div class="fsf-card">
        <form method="POST" action="{{ route('fs-skema.store') }}" id="form-fs-skema">
            @csrf

            @if ($errors->any())
                <div class="fsf-alert-error">
                    <strong>Ada isian yang perlu diperbaiki:</strong>
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="fsf-tabs">
                <label class="fsf-tab">
                    <input type="radio" name="skema" value="skema_2" @checked(old('skema', 'skema_2') === 'skema_2') data-preview-trigger>
                    <span>Skema 2</span>
                </label>
                <label class="fsf-tab">
                    <input type="radio" name="skema" value="skema_3" @checked(old('skema') === 'skema_3') data-preview-trigger>
                    <span>Skema 3</span>
                </label>
            </div>

            <div class="fsf-row">
                <div class="fsf-field">
                    <label>Nama Tempat/Lokasi (Nama SPKLU)</label>
                    <div class="fsf-combobox" id="combobox-lokasi">
                        <input type="hidden" name="nama_lokasi" id="input-nama-lokasi" value="{{ old('nama_lokasi') }}" data-preview-trigger>
                        <input type="hidden" name="kandidat_id" id="input-kandidat-id" value="{{ old('kandidat_id') }}">
                        <button type="button" class="fsf-combobox-trigger">
                            <span class="fsf-combobox-label {{ old('nama_lokasi') ? 'has-value' : '' }}" id="label-nama-lokasi">{{ old('nama_lokasi') ?: 'Pilih lokasi dari data Probabilitas...' }}</span>
                            <svg class="fsf-combobox-chevron" viewBox="0 0 10 6" fill="none"><path d="M1 1L5 5L9 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                        </button>
                        <div class="fsf-combobox-panel">
                            <input type="text" class="fsf-combobox-search" placeholder="Cari lokasi...">
                            <div class="fsf-combobox-options">
                                @foreach ($probabilitasList as $p)
                                    <div class="fsf-combobox-option"
                                         data-label="{{ $p->lokasi }}"
                                         data-lat="{{ $p->tikor_lat }}"
                                         data-lng="{{ $p->tikor_lng }}"
                                         data-kandidat-id="{{ $p->kandidatPrioritas->id ?? '' }}">
                                        {{ $p->lokasi }}
                                    </div>
                                @endforeach
                            </div>
                            <div class="fsf-combobox-empty">Tidak ada lokasi yang cocok.</div>
                        </div>
                    </div>
                    <p class="fsf-hint">Ditarik dari data Probabilitas — koordinat &amp; kandidat terkait terisi otomatis saat dipilih.</p>
                </div>
                <div class="fsf-field">
                    <label>Titik Kordinat</label>
                    <input type="text" name="titik_koordinat" id="input-titik-koordinat" value="{{ old('titik_koordinat') }}" placeholder="-6.1944, 106.8318" data-preview-trigger>
                    <p class="fsf-hint">Terisi otomatis saat pilih lokasi, tapi tetap bisa diedit manual.</p>
                    <p class="fsf-hint">Format: lat, lng — dipakai buat hitung 3 SPKLU terdekat</p>
                </div>
            </div>

            {{-- Latitude/Longitude readonly — otomatis kepecah dari Titik Kordinat di atas --}}
            <div class="fsf-row">
                <div class="fsf-field">
                    <label>Latitude (terbaca otomatis)</label>
                    <input type="text" id="input-latitude-otomatis" value="" readonly placeholder="—">
                </div>
                <div class="fsf-field">
                    <label>Longitude (terbaca otomatis)</label>
                    <input type="text" id="input-longitude-otomatis" value="" readonly placeholder="—">
                </div>
            </div>

            <div class="fsf-row">
                <div class="fsf-field">
                    <label>Layanan Listrik</label>
                    <select name="layanan_listrik" data-preview-trigger>
                        <option value="">Pilih jenis layanan...</option>
                        <option value="TM" @selected(old('layanan_listrik') === 'TM')>TM</option>
                        <option value="TR" @selected(old('layanan_listrik') === 'TR')>TR</option>
                        <option value="LTR" @selected(old('layanan_listrik') === 'LTR')>LTR</option>
                    </select>
                </div>
            </div>

            {{-- SKEMA 2 --}}
            <div id="blok-skema-2">
                <div class="fsf-row">
                    <div class="fsf-field">
                        <label>Total RAB Investasi (Rp)</label>
                        <input type="text" inputmode="numeric" class="fsf-rupiah-display" data-target="total_rab_investasi" placeholder="Contoh: 500.000.000">
                        <input type="hidden" name="total_rab_investasi" id="hidden-total_rab_investasi" value="{{ old('total_rab_investasi') }}" data-preview-trigger>
                    </div>
                    <div class="fsf-field">
                        <label>Mobil/hari</label>
                        <input type="number" name="mobil_per_hari" value="{{ old('mobil_per_hari') }}" placeholder="Masukan asumsi mobil per hari" required data-preview-trigger>
                    </div>
                </div>
            </div>

            {{-- SKEMA 3 --}}
            <div id="blok-skema-3" class="fsf-skema3-only">
                <div class="fsf-row">
                    <div class="fsf-field">
                        <label>RAB Mitra Mesin (Rp)</label>
                        <input type="text" inputmode="numeric" class="fsf-rupiah-display" data-target="rab_mitra_mesin" placeholder="Contoh: 500.000.000">
                        <input type="hidden" name="rab_mitra_mesin" id="hidden-rab_mitra_mesin" value="{{ old('rab_mitra_mesin') }}" data-preview-trigger>
                    </div>
                    <div class="fsf-field">
                        <label>RAB Mitra Lahan (Rp)</label>
                        <input type="text" inputmode="numeric" class="fsf-rupiah-display" data-target="rab_mitra_lahan" placeholder="Contoh: 200.000.000">
                        <input type="hidden" name="rab_mitra_lahan" id="hidden-rab_mitra_lahan" value="{{ old('rab_mitra_lahan') }}" data-preview-trigger>
                    </div>
                </div>
                <div class="fsf-row">
                    <div class="fsf-field">
                        <label>Mobil/hari</label>
                        <input type="number" name="mobil_per_hari_skema3" value="{{ old('mobil_per_hari') }}" placeholder="Masukan asumsi mobil per hari" data-preview-trigger>
                    </div>
                    <div class="fsf-field">
                        <label>Sharing Profit Mitra Lahan</label>
                        <input type="number" step="0.01" min="0" max="1" name="sharing_provit_mitra_lahan" value="{{ old('sharing_provit_mitra_lahan', 0.10) }}" placeholder="0.10" data-preview-trigger>
                        <p class="fsf-hint">Nilai 0–1 (contoh 0.10 = 10%). Default 10% jika dikosongkan.</p>
                    </div>
                </div>
            </div>

            <div class="fsf-row">
                <div class="fsf-field">
                    <label>Transaksi kWh/Mobil</label>
                    <input type="number" step="0.01" name="transaksi_kwh_per_mobil" value="{{ old('transaksi_kwh_per_mobil') }}" placeholder="Masukan Transaksi kWh/mobil" required data-preview-trigger>
                </div>
                <div class="fsf-field">
                    <label>Masa Kontrak (Tahun)</label>
                    <input type="number" name="masa_kontrak_tahun" value="{{ old('masa_kontrak_tahun', 5) }}" min="1" max="30" required data-preview-trigger>
                    <p class="fsf-hint">Menentukan panjang proyeksi ROI (misal 5 = ROI dihitung 5 tahun ke depan).</p>
                </div>
            </div>

            <div class="fsf-section-title">Penilaian Lokasi</div>

            <label class="fsf-label-group">Fasilitas (maks 40 poin)</label>
            <div class="fsf-chip-group">
                @foreach (\App\Services\FsSkemaCalculatorService::LABEL_FASILITAS as $val => $label)
                    <label class="fsf-chip">
                        <input type="checkbox" name="fasilitas[]" value="{{ $val }}" @checked(in_array($val, old('fasilitas', []))) data-preview-trigger>
                        <span>{{ $label }}</span>
                    </label>
                @endforeach
            </div>

            <div class="fsf-field-half" style="max-width: calc(50% - 9px); margin-bottom:18px;">
                <label>Kesiapan Jaringan (maks 20 poin)</label>
                <select name="kesiapan_jaringan" data-preview-trigger>
                    <option value="">Pilih kesiapan jaringan...</option>
                    @foreach (\App\Services\FsSkemaCalculatorService::OPSI_KESIAPAN_JARINGAN as $label => $poinMax)
                        <option value="{{ $label }}" @selected(old('kesiapan_jaringan') === $label)>
                            {{ $label }} ({{ $poinMax }} poin)
                        </option>
                    @endforeach
                </select>
            </div>

            <label class="fsf-label-group">Okupansi (maks 40 poin)</label>
            <div class="fsf-chip-group">
                @foreach (\App\Services\FsSkemaCalculatorService::LABEL_OKUPANSI as $val => $label)
                    <label class="fsf-chip">
                        <input type="checkbox" name="okupansi[]" value="{{ $val }}" @checked(in_array($val, old('okupansi', []))) data-preview-trigger>
                        <span>{{ $label }}</span>
                    </label>
                @endforeach
            </div>

            {{-- Ringkasan Kelayakan Lokasi — dipindah ke kiri, tepat di bawah
                 Penilaian Lokasi supaya nyambung sama input poin di atasnya. --}}
            <div class="fsf-mini-card">
                <div class="fsf-mini-card-header">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    Ringkasan Kelayakan Lokasi
                </div>
                <div class="fsf-mini-card-body">
                    <div class="fsp-poin-row"><span>Fasilitas</span><span id="fsp-poin-fasilitas">0 / 40</span></div>
                    <div class="fsp-poin-row"><span>Kesiapan Jaringan</span><span id="fsp-poin-jaringan">0 / 20</span></div>
                    <div class="fsp-poin-row"><span>Okupansi</span><span id="fsp-poin-okupansi">0 / 40</span></div>
                    <div class="fsp-poin-row"><span>TOTAL</span><span id="fsp-poin-total">0 / 100</span></div>
                    <div class="fsp-status-box fsp-status-netral" id="fsp-status-box">Status Kelayakan: —</div>
                </div>
            </div>

            <div class="fsf-actions">
                <a href="{{ route('fs-skema.index') }}" class="fsf-btn-outline">Batal</a>
                <button type="submit" class="fsf-btn-primary">Simpan</button>
            </div>
        </form>
    </div>

    {{-- KOLOM KANAN: LIVE PREVIEW --}}
    <div>
        <div class="fsp-card">
            <div class="fsp-card-header">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                3 SPKLU Terdekat <span id="fsp-loading-spklu" class="fsp-loading" style="display:none">memuat…</span>
            </div>
            <div class="fsp-card-body">
                <div id="fsp-spklu-empty" class="fsp-empty">Isi Titik Kordinat untuk melihat SPKLU terdekat.</div>
                <table class="fsp-table" id="fsp-spklu-table" style="display:none">
                    <thead><tr><th>Nama SPKLU</th><th>Jarak</th><th>Status Jarak</th></tr></thead>
                    <tbody id="fsp-spklu-body"></tbody>
                </table>
            </div>
        </div>

        {{-- Proyeksi ROI: tabel detail + estimasi teks --}}
        <div class="fsp-card">
            <div class="fsp-card-header">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
                Proyeksi ROI <span id="fsp-roi-tahun-label">5</span> Tahun <span id="fsp-loading-roi" class="fsp-loading" style="display:none">memuat…</span>
            </div>
            <div class="fsp-card-body">
                <div id="fsp-roi-empty" class="fsp-empty">Isi Mobil/hari &amp; Transaksi kWh/Mobil untuk melihat proyeksi.</div>
                <div id="fsp-roi-content" style="display:none">
                    <table class="fsp-table" id="fsp-roi-table">
                        <thead id="fsp-roi-head"></thead>
                        <tbody id="fsp-roi-body"></tbody>
                    </table>
                    <div class="fsp-estimasi-roi" id="fsp-estimasi-roi"></div>
                </div>
            </div>
        </div>

        {{-- Grafik Proyeksi ROI --}}
        <div class="fsp-card">
            <div class="fsp-card-header">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="2" y1="20" x2="22" y2="20"/></svg>
                Grafik Proyeksi ROI
            </div>
            <div class="fsp-card-body">
                <div id="fsp-roi-chart-empty" class="fsp-empty">Grafik akan tampil setelah data Proyeksi ROI di atas terisi.</div>
                <div id="fsp-roi-chart-wrap" style="display:none">
                    <canvas id="fsp-roi-chart" height="220"></canvas>
                </div>
            </div>
        </div>

        <div class="fsp-card">
            <div class="fsp-card-header">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                Ringkasan Analisis
            </div>
            <div class="fsp-card-body">
                <p class="fsp-narasi-placeholder" id="fsp-narasi">Lengkapi form untuk melihat ringkasan analisis.</p>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
{{--
    Chart.js sekarang di-host LOKAL (public/vendor/chartjs/chart.umd.min.js),
    bukan dari CDN cdnjs.cloudflare.com lagi — supaya gak bergantung sama
    akses internet ke CDN (yang sempat gagal dimuat di jaringan ini).
--}}
<script src="{{ asset('vendor/chartjs/chart.umd.min.js') }}" onerror="window.__chartJsGagalDimuat = true"></script>
<script>
// ===== Field readonly Latitude/Longitude (parsing dari Titik Kordinat) =====
function perbaruiLatLng() {
    const nilai = document.getElementById('input-titik-koordinat').value;
    const bagian = nilai.split(',').map(s => s.trim());
    const lat = document.getElementById('input-latitude-otomatis');
    const lng = document.getElementById('input-longitude-otomatis');

    if (bagian.length === 2 && !isNaN(bagian[0]) && !isNaN(bagian[1]) && bagian[0] !== '' && bagian[1] !== '') {
        lat.value = bagian[0];
        lng.value = bagian[1];
    } else {
        lat.value = '';
        lng.value = '';
    }
}
document.getElementById('input-titik-koordinat').addEventListener('input', perbaruiLatLng);

// ===== Toggle Skema 2 / Skema 3 =====
function tandaiFieldMobil() {
    document.querySelectorAll('input[name="mobil_per_hari"], input[name="mobil_per_hari_disabled"]')
        .forEach(el => { if (!el.dataset.role) el.dataset.role = 'mobil-skema2'; });
    document.querySelectorAll('input[name="mobil_per_hari_skema3"]')
        .forEach(el => { if (!el.dataset.role) el.dataset.role = 'mobil-skema3'; });
}

function toggleSkema(val) {
    document.getElementById('blok-skema-2').style.display = val === 'skema_2' ? 'block' : 'none';
    document.getElementById('blok-skema-3').classList.toggle('fsf-skema3-only', val !== 'skema_3');

    tandaiFieldMobil();

    const mobilSkema2 = document.querySelector('[data-role="mobil-skema2"]');
    const mobilSkema3 = document.querySelector('[data-role="mobil-skema3"]');

    if (val === 'skema_3') {
        mobilSkema3.name = 'mobil_per_hari';
        mobilSkema2.name = 'mobil_per_hari_disabled';
        mobilSkema2.required = false;
        mobilSkema3.required = true;
    } else {
        mobilSkema2.name = 'mobil_per_hari';
        mobilSkema3.name = 'mobil_per_hari_disabled';
        mobilSkema2.required = true;
        mobilSkema3.required = false;
    }
}

document.querySelectorAll('input[name="skema"]').forEach(el => {
    el.addEventListener('change', () => { toggleSkema(el.value); jadwalkanPreview(); });
});

document.addEventListener('DOMContentLoaded', () => {
    const dipilih = document.querySelector('input[name="skema"]:checked')?.value || 'skema_2';
    toggleSkema(dipilih);
    initComboboxLokasi();
    initRupiahFormatter();
    perbaruiLatLng();
    jalankanPreview();
});

/* =====================================================================
   Format Rupiah live (titik ribuan) — input teks terpisah dari hidden
   input yang benar-benar dikirim (angka murni tanpa titik).
   ===================================================================== */
function formatRibuan(raw) {
    if (!raw) return '';
    return Number(raw).toLocaleString('id-ID');
}

function initRupiahFormatter() {
    document.querySelectorAll('.fsf-rupiah-display').forEach(displayEl => {
        const hiddenEl = document.getElementById('hidden-' + displayEl.dataset.target);
        if (!hiddenEl) return;

        if (hiddenEl.value) {
            displayEl.value = formatRibuan(hiddenEl.value);
        }

        displayEl.addEventListener('input', function () {
            const raw = this.value.replace(/\D/g, '');
            hiddenEl.value = raw;
            this.value = formatRibuan(raw);
            hiddenEl.dispatchEvent(new Event('input', { bubbles: true }));
        });
    });
}

/* =====================================================================
   Combobox pencarian "Nama Tempat/Lokasi" — sumber data: Probabilitas
   ===================================================================== */
function initComboboxLokasi() {
    const root = document.getElementById('combobox-lokasi');
    const trigger = root.querySelector('.fsf-combobox-trigger');
    const label = document.getElementById('label-nama-lokasi');
    const hiddenInput = document.getElementById('input-nama-lokasi');
    const hiddenKandidat = document.getElementById('input-kandidat-id');
    const panel = root.querySelector('.fsf-combobox-panel');
    const search = root.querySelector('.fsf-combobox-search');
    const emptyState = root.querySelector('.fsf-combobox-empty');
    const options = Array.from(root.querySelectorAll('.fsf-combobox-option'));
    const koordinatInput = document.getElementById('input-titik-koordinat');

    function closePanel() {
        panel.classList.remove('open');
        root.classList.remove('open');
    }
    function openPanel() {
        panel.classList.add('open');
        root.classList.add('open');
        search.value = '';
        filterOptions('');
        setTimeout(() => search.focus(), 0);
    }

    trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        panel.classList.contains('open') ? closePanel() : openPanel();
    });

    function filterOptions(query) {
        const q = query.trim().toLowerCase();
        let anyVisible = false;
        options.forEach(opt => {
            const match = opt.dataset.label.toLowerCase().includes(q);
            opt.style.display = match ? '' : 'none';
            if (match) anyVisible = true;
        });
        emptyState.style.display = anyVisible ? 'none' : 'block';
    }

    search.addEventListener('input', () => filterOptions(search.value));
    search.addEventListener('click', e => e.stopPropagation());

    options.forEach(opt => {
        opt.addEventListener('click', function () {
            hiddenInput.value = this.dataset.label;
            label.textContent = this.dataset.label;
            label.classList.add('has-value');
            options.forEach(o => o.classList.remove('selected'));
            this.classList.add('selected');

            if (this.dataset.lat && this.dataset.lng) {
                koordinatInput.value = `${this.dataset.lat}, ${this.dataset.lng}`;
            }
            hiddenKandidat.value = this.dataset.kandidatId || '';

            closePanel();
            perbaruiLatLng();
            jadwalkanPreview();
        });
    });

    document.addEventListener('click', function (e) {
        if (!root.contains(e.target)) closePanel();
    });
}

document.getElementById('form-fs-skema').addEventListener('submit', function (e) {
    const namaLokasi = document.getElementById('input-nama-lokasi').value.trim();
    if (!namaLokasi) {
        e.preventDefault();
        document.getElementById('combobox-lokasi').querySelector('.fsf-combobox-trigger').focus();
        alert('Pilih lokasi terlebih dahulu dari daftar Probabilitas.');
    }
});

// ===== LIVE PREVIEW (AJAX) =====
const PREVIEW_URL = '{{ route('fs-skema.preview') }}';
let timerPreview = null;
let chartRoi = null;

// Cek apakah library Chart.js benar-benar tersedia di window.
function chartJsSiap() {
    return typeof Chart !== 'undefined' && !window.__chartJsGagalDimuat;
}

function jadwalkanPreview() {
    clearTimeout(timerPreview);
    timerPreview = setTimeout(jalankanPreview, 500);
}

document.getElementById('form-fs-skema').addEventListener('input', jadwalkanPreview);
document.getElementById('form-fs-skema').addEventListener('change', jadwalkanPreview);

function formatRupiah(angka) {
    return 'Rp ' + Number(angka || 0).toLocaleString('id-ID');
}

async function jalankanPreview() {
    const form = document.getElementById('form-fs-skema');
    const formData = new FormData(form);
    formData.delete('_method');

    document.getElementById('fsp-loading-spklu').style.display = 'inline';
    document.getElementById('fsp-loading-roi').style.display = 'inline';

    try {
        const res = await fetch(PREVIEW_URL, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name=_token]').value,
                'Accept': 'application/json',
            },
            body: formData,
        });

        if (!res.ok) {
            const errBody = await res.json().catch(() => null);
            console.warn('Preview FS Skema ditolak server (status ' + res.status + '):', errBody);
            return;
        }
        const data = await res.json();
        renderPoin(data.poin);
        renderSpklu(data.spklu_terdekat);
        renderRoi(data.proyeksi_roi);
        renderNarasi(data.narasi_analisis);
    } catch (e) {
        console.error('Preview FS Skema gagal:', e);
    } finally {
        document.getElementById('fsp-loading-spklu').style.display = 'none';
        document.getElementById('fsp-loading-roi').style.display = 'none';
    }
}

function renderPoin(poin) {
    if (!poin) return;
    document.getElementById('fsp-poin-fasilitas').textContent = poin.fasilitas + ' / 40';
    document.getElementById('fsp-poin-jaringan').textContent = poin.jaringan + ' / 20';
    document.getElementById('fsp-poin-okupansi').textContent = poin.okupansi + ' / 40';
    document.getElementById('fsp-poin-total').textContent = poin.total + ' / 100';

    const box = document.getElementById('fsp-status-box');
    box.textContent = 'Status Kelayakan: ' + poin.status;
    box.className = 'fsp-status-box ' + (
        poin.status === 'Layak' ? 'fsp-status-hijau' :
        poin.status === 'Menjadi Pertimbangan' ? 'fsp-status-kuning' : 'fsp-status-merah'
    );
}

function renderSpklu(list) {
    const empty = document.getElementById('fsp-spklu-empty');
    const table = document.getElementById('fsp-spklu-table');
    const body = document.getElementById('fsp-spklu-body');

    if (!list || list.length === 0) {
        empty.style.display = 'block';
        table.style.display = 'none';
        return;
    }

    empty.style.display = 'none';
    table.style.display = 'table';
    body.innerHTML = list.map(s => {
        let kelasStatus = 'fsp-jarak-belum';
        if (s.status_jarak === 'Bagus') kelasStatus = 'fsp-jarak-bagus';
        else if (s.status_jarak && s.status_jarak.includes('kanibalisasi')) kelasStatus = 'fsp-jarak-risiko';

        return `<tr>
            <td>${s.nama}</td>
            <td>${Number(s.jarak_km).toFixed(2)} km</td>
            <td class="${kelasStatus}">${s.status_jarak}</td>
        </tr>`;
    }).join('');
}

function renderRoi(roi) {
    const empty = document.getElementById('fsp-roi-empty');
    const content = document.getElementById('fsp-roi-content');
    const head = document.getElementById('fsp-roi-head');
    const body = document.getElementById('fsp-roi-body');
    const labelTahun = document.getElementById('fsp-roi-tahun-label');
    const chartEmpty = document.getElementById('fsp-roi-chart-empty');
    const chartWrap = document.getElementById('fsp-roi-chart-wrap');

    if (!roi) {
        empty.style.display = 'block';
        content.style.display = 'none';
        chartEmpty.style.display = 'block';
        chartEmpty.textContent = 'Grafik akan tampil setelah data Proyeksi ROI di atas terisi.';
        chartEmpty.classList.remove('fsp-chart-error');
        chartWrap.style.display = 'none';
        if (chartRoi) { chartRoi.destroy(); chartRoi = null; }
        return;
    }

    empty.style.display = 'none';
    content.style.display = 'block';
    labelTahun.textContent = roi.masa_kontrak_tahun;

    if (roi.tipe === 'skema_2') {
        head.innerHTML = '<tr><th>Tahun</th><th>Mobil/hari</th><th>Transaksi/tahun</th><th>Energi (kWh)</th><th>Pendapatan</th><th>Kumulatif</th></tr>';
        body.innerHTML = roi.tahunan.map(r => `<tr>
            <td>${r.tahun}${r.sudah_bep ? ' ✓BEP' : ''}</td>
            <td>${r.mobil_per_hari}</td>
            <td>${Number(r.transaksi_per_tahun).toLocaleString('id-ID')}</td>
            <td>${Number(r.energi_kwh_per_tahun).toLocaleString('id-ID')}</td>
            <td>${formatRupiah(r.pendapatan_mitra)}</td>
            <td>${formatRupiah(r.kumulatif)}</td>
        </tr>`).join('');

        document.getElementById('fsp-estimasi-roi').innerHTML =
            `<strong>Estimasi ROI:</strong> ${roi.estimasi_roi_teks}`;
    } else {
        head.innerHTML = '<tr><th>Tahun</th><th>Mobil/hari</th><th>Transaksi/tahun</th><th>Energi (kWh)</th><th>Pendpt. Mesin</th><th>Pendpt. Lahan</th></tr>';
        body.innerHTML = roi.tahunan.map(r => `<tr>
            <td>${r.tahun}</td>
            <td>${r.mobil_per_hari}</td>
            <td>${Number(r.transaksi_per_tahun).toLocaleString('id-ID')}</td>
            <td>${Number(r.energi_kwh_per_tahun).toLocaleString('id-ID')}</td>
            <td>${formatRupiah(r.pendapatan_mesin)}${r.sudah_bep_mesin ? ' ✓BEP' : ''}</td>
            <td>${formatRupiah(r.pendapatan_lahan)}${r.sudah_bep_lahan ? ' ✓BEP' : ''}</td>
        </tr>`).join('');

        document.getElementById('fsp-estimasi-roi').innerHTML =
            `<strong>Estimasi ROI Mitra Mesin:</strong> ${roi.estimasi_roi_mesin_teks}<br>`
            + `<strong>Estimasi ROI Mitra Lahan:</strong> ${roi.estimasi_roi_lahan_teks}`;
    }

    renderChartRoi(roi);
}

function renderChartRoi(roi) {
    const chartEmpty = document.getElementById('fsp-roi-chart-empty');
    const chartWrap = document.getElementById('fsp-roi-chart-wrap');

    if (!chartJsSiap()) {
        if (chartRoi) { chartRoi.destroy(); chartRoi = null; }
        chartWrap.style.display = 'none';
        chartEmpty.style.display = 'block';
        chartEmpty.textContent = 'Grafik tidak bisa ditampilkan: library Chart.js gagal dimuat. Pastikan file public/vendor/chartjs/chart.umd.min.js ada.';
        chartEmpty.classList.add('fsp-chart-error');
        return;
    }

    try {
        chartEmpty.style.display = 'none';
        chartWrap.style.display = 'block';

        const canvas = document.getElementById('fsp-roi-chart');
        const labelsTahun = roi.tahunan.map(r => 'Tahun ' + r.tahun);

        const datasets = roi.tipe === 'skema_2'
            ? [{
                label: 'Progres BEP (%)',
                data: roi.tahunan.map(r => r.persen_progres),
                borderColor: '#0081AB',
                backgroundColor: 'rgba(0,129,171,0.15)',
                tension: 0.3,
                fill: true,
            }]
            : [
                {
                    label: 'Progres BEP Mitra Mesin (%)',
                    data: roi.tahunan.map(r => r.persen_progres_mesin),
                    borderColor: '#0081AB',
                    backgroundColor: 'rgba(0,129,171,0.15)',
                    tension: 0.3,
                    fill: true,
                },
                {
                    label: 'Progres BEP Mitra Lahan (%)',
                    data: roi.tahunan.map(r => r.persen_progres_lahan),
                    borderColor: '#F59E0B',
                    backgroundColor: 'rgba(245,158,11,0.12)',
                    tension: 0.3,
                    fill: true,
                },
            ];

        if (chartRoi) {
            chartRoi.data.labels = labelsTahun;
            chartRoi.data.datasets = datasets;
            chartRoi.update();
            return;
        }

        chartRoi = new Chart(canvas, {
            type: 'line',
            data: { labels: labelsTahun, datasets },
            options: {
                responsive: true,
                scales: {
                    y: {
                        ticks: { callback: v => v + '%' },
                        title: { display: true, text: 'Progres menuju BEP (%)' },
                    },
                },
                plugins: { legend: { display: true, position: 'bottom' } },
            },
        });
    } catch (e) {
        console.error('Gagal membuat grafik ROI:', e);
        if (chartRoi) { chartRoi.destroy(); chartRoi = null; }
        chartWrap.style.display = 'none';
        chartEmpty.style.display = 'block';
        chartEmpty.textContent = 'Grafik gagal ditampilkan karena kesalahan teknis. Cek console browser (F12) untuk detail error.';
        chartEmpty.classList.add('fsp-chart-error');
    }
}

function renderNarasi(narasi) {
    const el = document.getElementById('fsp-narasi');
    if (narasi) {
        el.textContent = narasi;
        el.classList.remove('fsp-narasi-placeholder');
        el.classList.add('fsp-narasi');
    } else {
        el.textContent = 'Lengkapi form untuk melihat ringkasan analisis.';
        el.classList.add('fsp-narasi-placeholder');
        el.classList.remove('fsp-narasi');
    }
}
</script>
@endpush