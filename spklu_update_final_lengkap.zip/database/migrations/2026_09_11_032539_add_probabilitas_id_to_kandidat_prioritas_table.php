<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('kandidat_prioritas', function (Blueprint $table) {
            $table->foreignId('probabilitas_id')
                ->nullable()
                ->after('id')
                ->constrained('probabilitas')
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('kandidat_prioritas', function (Blueprint $table) {
            $table->dropForeign(['probabilitas_id']);
            $table->dropColumn('probabilitas_id');
        });
    }
};
